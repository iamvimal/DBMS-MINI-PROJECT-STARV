# Starv


DBMS project for online Food Ordering system.

The frontend specifically can be found in `front-end/` folder.

To run the server, run the following command:

    python manage.py runserver

## Features
* Supports Restaurant and Customer login and signup.
* User can enter and edit details.
* User can place orders from multiple restaurants.
* A restaurant can update their menu and add new items to their menu.
* Both user and restaurant can check their history logs.
* Crazy UI

## Members
* Sehran Kahn 
* Vimal Shetty (https://github.com/iamvimals)

