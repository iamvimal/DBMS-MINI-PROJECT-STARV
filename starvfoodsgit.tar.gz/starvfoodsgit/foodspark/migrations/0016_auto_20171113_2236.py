# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('foodspark', '0015_auto_20170601_1711'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='customer',
            name='city',
        ),
        migrations.RemoveField(
            model_name='fooditem',
            name='availability_time',
        ),
        migrations.RemoveField(
            model_name='restaurant',
            name='cuisine',
        ),
        migrations.RemoveField(
            model_name='restaurant',
            name='imgurl',
        ),
        migrations.RemoveField(
            model_name='restaurant',
            name='res_type',
        ),
        migrations.AddField(
            model_name='restaurant',
            name='subname',
            field=models.CharField(default='rest', max_length=200),
        ),
    ]
